document.addEventListener("DOMContentLoaded", function() {
    document.getElementById("formularioCompra").addEventListener("submit", function(event) {
        let inputs = document.querySelectorAll("input[required]");
        let valid = true;

        inputs.forEach(input => {
            let errorSpan = document.getElementById(`error-${input.id}`);
            if (input.value.trim() === "") {
                event.preventDefault();
                errorSpan.style.display = "block";
                input.setAttribute("aria-invalid", "true");
                valid = false;
            } else {
                errorSpan.style.display = "none";
                input.removeAttribute("aria-invalid");
            }
        });

        if (valid) {
            alert("¡Compra realizada con éxito!");
        }
    });

    function toggleForm(id) {
        let forms = document.querySelectorAll(".hidden");
        forms.forEach(form => {
            if (form.id !== id) {
                form.classList.remove("show");
                form.style.display = "none";
            }
        });

        let form = document.getElementById(id);
        let isHidden = !form.classList.contains("show");
        form.classList.toggle("show", isHidden);
        form.style.display = isHidden ? "block" : "none";
        form.setAttribute('aria-hidden', !isHidden);
    }

    document.querySelectorAll(".opcion").forEach(opcion => {
        opcion.addEventListener("click", function() {
            let targetId = this.getAttribute("onclick").match(/'([^']+)'/)[1];
            toggleForm(targetId);
        });
    });
});
